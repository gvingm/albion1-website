# 🏢 Альбион-1: Интегратор Битрикс24

[![🚀 Deploy](https://github.com/gvingm/albion1-website/actions/workflows/deploy.yml/badge.svg)](https://github.com/gvingm/albion1-website/actions/workflows/deploy.yml)
[![🌐 Live Demo](https://img.shields.io/badge/Live-Demo-2196F3.svg?style=flat&logo=github)](https://gvingm.github.io/albion1-website/)
[![⚛️ React](https://img.shields.io/badge/React-19-61DAFB.svg?style=flat&logo=react)](https://reactjs.org/)
[![📝 TypeScript](https://img.shields.io/badge/TypeScript-5.6-3178C6.svg?style=flat&logo=typescript)](https://www.typescriptlang.org/)
[![🎨 Tailwind CSS](https://img.shields.io/badge/Tailwind-4-06B6D4.svg?style=flat&logo=tailwindcss)](https://tailwindcss.com/)
[![⚡ Vite](https://img.shields.io/badge/Vite-7-646CFF.svg?style=flat&logo=vite)](https://vitejs.dev/)
[![📦 pnpm](https://img.shields.io/badge/pnpm-10.15-F69220.svg?style=flat&logo=pnpm)](https://pnpm.io/)

## 🌐 Живая демонстрация

**[👉 Посмотреть сайт](https://gvingm.github.io/albion1-website/)**

> 💡 *Сайт автоматически деплоится на GitHub Pages при каждом обновлении*

## 📋 О проекте

Профессиональный веб-сайт компании **Альбион-1**, специализирующейся на:
- 🎯 **Интеграции Bitrix24** — полный цикл внедрения CRM
- ⚡ **Оптимизации бизнес-процессов** — аудит и проектирование
- 📊 **Цифровом маркетинге** — сквозная аналитика и лидогенерация
- 🤖 **Голосовых роботах на LLM** — AI-Powered BDR и NLP-боты

## 🚀 Быстрый старт

### Просмотр без установки
Откройте [`working-homepage.html`](./working-homepage.html) для мгновенного просмотра!

### Локальная разработка
```bash
# Клонирование
git clone https://github.com/gvingm/albion1-website.git
cd albion1-website

# Установка зависимостей
pnpm install

# Запуск dev сервера
pnpm dev
```

## 🎨 Особенности дизайна

- ✅ **Адаптивный дизайн** - Mobile-first подход
- 🎨 **Современная цветовая схема** - OKLCH палитра
- ⚡ **Быстрая загрузка** - оптимизированные ресурсы
- ♿ **Доступность** - WCAG 2.1 совместимость
- 🔍 **SEO оптимизация** - мета теги, sitemap, robots.txt

## 📁 Структура проекта

```
albion1-website/
├── .github/workflows/       # CI/CD автоматизация
├── client/                  # React + TypeScript frontend
├── server/                  # Express.js backend
├── public/                  # Статические файлы
├── patches/                 # Патчи зависимостей
├── shared/                  # Общие типы
└── 📄 Документация
```

## 🛠 Технологический стек

| Технология | Версия | Назначение |
|------------|---------|------------|
| React | 19.0.0 | UI фреймворк |
| TypeScript | 5.6.3 | Типобезопасность |
| Tailwind CSS | 4.1.14 | Стилизация |
| Vite | 7.1.7 | Сборка и dev сервер |
| pnpm | 10.15.0 | Менеджер пакетов |
| GitHub Actions | - | CI/CD |

## 📊 Статистика проекта

- ⚡ **Время загрузки**: < 2 секунды
- 📱 **Адаптивность**: 320px - 4K
- 🎨 **Цветовая палитра**: OKLCH профессиональный синий
- 🔤 **Шрифт**: Inter (400-800 вес)
- 📦 **Размер сборки**: оптимизирован под GitHub Pages

## 🎯 Ключевые страницы

1. **[Главная](https://gvingm.github.io/albion1-website/)** - Hero секция, преимущества, кейсы
2. **[Услуги](https://gvingm.github.io/albion1-website/services)** - Детальное описание услуг
3. **[Кейсы](https://gvingm.github.io/albion1-website/case-studies)** - Реальные результаты
4. **[О компании](https://gvingm.github.io/albion1-website/about)** - Информация о компании
5. **[Контакты](https://gvingm.github.io/albion1-website/contact)** - Форма обратной связи

## 🚀 Деплой

Сайт автоматически деплоится на GitHub Pages при пуше в `main` ветку.

### Ручной деплой
```bash
pnpm build
# GitHub Actions сделает остальное автоматически
```

## 📞 Контакты компании

- 📱 **Телефон**: [+7 (995) 5996615](tel:+79955996615)
- 📧 **Email**: [560898@gmail.com](mailto:560898@gmail.com)
- 💬 **Telegram**: [@gvingm](https://t.me/gvingm)
- 📍 **Город**: Санкт-Петербург

## 📄 Документация

- [📖 Полное README](./README.md) - детальная документация
- [🔧 Восстановление дизайна](./DESIGN_RECOVERY.md) - если сайт без стилей
- [🚀 Деплой](./DEPLOYMENT.md) - инструкции по деплою
- [🤝 Contributing](./CONTRIBUTING.md) - как участвовать в проекте

## 🏆 Достижения

- ✅ 15+ лет опыта в маркетинге
- ✅ 5+ лет с Bitrix24
- ✅ 10+ успешных проектов
- ✅ 4x средний рост оборота клиентов

## 🔄 Обновления

| Дата | Версия | Изменения |
|------|---------|-----------|
| 28.12.2024 | 1.0.0 | Первоначальная публикация |
| 28.12.2024 | 1.0.1 | Исправлена ошибка с дизайном, добавлен GitHub Actions |

## 🤝 Участие в проекте

1. Форкните репозиторий
2. Создайте ветку для изменений
3. Сделайте коммит с описанием
4. Отправьте pull request

Подробности в [CONTRIBUTING.md](./CONTRIBUTING.md)

## 📄 Лицензия

MIT License - см. [LICENSE](./LICENSE) файл.

---

<div align="center">
  <p><strong>⭐ Поставьте звезду если проект был полезен!</strong></p>
  <p>Made with ❤️ in Saint Petersburg, Russia</p>
  <p><sub>Последнее обновление: 28 декабря 2024</sub></p>
</div>